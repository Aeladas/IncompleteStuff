%{
Calendar - July 2019
720x480 -> background
 c x r
6 h and v with a 10 pixel width
Cell 1(Pic) - 340x480 - 1
Cell2(Days) - 20x60 - 7
Cell3(Num) - 60x60 - 35
'weekday names': 20x60
Numbers : 40x20

Frame (black, 20 pixels), best cropping to a smaller sized image :)
Create 2 smaller image
%}
artist = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\Armin.jpg");
latestRelease = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\Balance.jpg");
recordLabel = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\Armada.png");
image0 = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\0.bmp");
image1 = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\1.bmp");
image2 = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\2.bmp");
image3 = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\3.bmp");
image4 = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\4.bmp");
image5 = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\5.bmp");
image6 = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\6.bmp");
image7 = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\7.bmp");
image8 = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\8.bmp");
image9 = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\9.bmp");
month = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\july2019.bmp");
monday = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\monday.bmp");
tuesday = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\tuesday.bmp");
wednesday = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\wednesday.bmp");
thursday = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\thursday.bmp");
friday = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\friday.bmp");
saturday = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\saturday.bmp");
sunday = imread("C:\Users\aaron_000\Documents\MATLAB\Calendar\sunday.bmp");

%{
This is only to just check that the images will load...
imshow(artist);
imshow(latestRelease)
imshow(image0);
imshow(image1);
imshow(image2);
imshow(image3);
imshow(image4);
imshow(image5);
imshow(image6);
imshow(image7);
imshow(image8);
imshow(image9);
imshow(month);
imshow(monday);
imshow(tuesday);
imshow(wednesday);
imshow(thursday);
imshow(friday);
imshow(saturday);
imshow(sunday);
%}

%   1. Crop the main image & sub images
artist = imresize(artist, [340, 480]);
latestRelease = imresize(latestRelease, [70, 135]);
recordLabel = imresize(recordLabel, [70,135]);
month = imresize(month, [25, 75]);
base = zeros(720, 480, 3);
base = uint8(base);
%artist = rgb2gray(artist);
%latestRelease = rgb2gray(latestRelease);
monday = cat(3, monday, monday, monday);
tuesday = cat(3, tuesday, tuesday, tuesday);
wednesday = cat(3, wednesday, wednesday, wednesday);
thursday = cat(3, thursday, thursday, thursday);
friday = cat(3, friday, friday, friday);
saturday = cat(3, saturday, saturday, saturday);
sunday = cat(3, sunday, sunday, sunday);
image0 = cat(3, image0, image0, image0);
image1 = cat(3, image1, image1, image1);
image2 = cat(3, image2, image2, image2);
image3 = cat(3, image3, image3, image3);
image4 = cat(3, image4, image4, image4);
image5 = cat(3, image5, image5, image5);
image6 = cat(3, image6, image6, image6);
image7 = cat(3, image7, image7, image7);
image8 = cat(3, image8, image8, image8);
image9 = cat(3, image9, image9, image9);

base(1:340, 1:480, 1:3) = artist(1:340,1:480,1:3);
base(650:719, 345:479, 1:3) = latestRelease(1:70, 1:135, 1:3);
base(650:719, 210:344, 1:3) = recordLabel(1:70, 1:135, 1:3);
%figure, imshow(base);

% 2. Borders
base(340:350, 1:480, 1) = 198;
base(370:380, 1:480, 1) = 198;
base(340:350, 1:480, 2) = 255;
base(370:380, 1:480, 2) = 255;
base(340:350, 1:480, 3) = 0;
base(370:380, 1:480, 3) = 0;

base(350:720, 60:70, 1) = 198;
base(350:720, 130:140, 1) = 198;
base(350:720, 200:210, 1) = 198;
base(350:650, 270:280, 1) = 198;
base(350:650, 340:350, 1) = 198;
base(350:650, 410:420, 1) = 198;

base(350:720, 60:70, 2) = 255;
base(350:720, 130:140, 2) = 255;
base(350:720, 200:210, 2) = 255;
base(350:650, 270:280, 2) = 255;
base(350:650, 340:350, 2) = 255;
base(350:650, 410:420, 2) = 255;

base(350:720, 60:70, 3) = 0;
base(350:720, 130:140, 3) = 0;
base(350:720, 200:210, 3) = 0;
base(350:650, 270:280, 3) = 0;
base(350:650, 340:350, 3) = 0;
base(350:650, 410:420, 3) = 0;

base(430:440, 1:480, 1) = 198;
base(500:510, 1:480, 1) = 198;
base(570:580, 1:480, 1) = 198;
base(640:650, 1:480, 1) = 198;

base(430:440, 1:480, 2) = 255;
base(500:510, 1:480, 2) = 255;
base(570:580, 1:480, 2) = 255;
base(640:650, 1:480, 2) = 255;

base(430:440, 1:480, 3) = 0;
base(500:510, 1:480, 3) = 0;
base(570:580, 1:480, 3) = 0;
base(640:650, 1:480, 3) = 0;
%figure, imshow(base)

% 3. Insert the weekdays
base(351:370, 1:60, 1:3) = monday(1:20, 1:60, 1:3);
base(351:370, 70:129, 1:3) = tuesday(1:20, 1:60, 1:3);
base(351:370, 140:199, 1:3) = wednesday(1:20, 1:60, 1:3);
base(351:370, 210:269, 1:3) = thursday(1:20, 1:60, 1:3);
base(351:370, 280:339, 1:3) = friday(1:20, 1:60, 1:3);
base(351:370, 350:409, 1:3) = saturday(1:20, 1:60, 1:3);
base(351:370, 420:479, 1:3) = sunday(1:20, 1:60, 1:3);

% 4. Insert Numbers
    %First Row 1-7
base(380:419, 1:20, 1:3) = image1(1:40, 1:20, 1:3);
base(380:419, 70:89, 1:3) = image2(1:40, 1:20, 1:3);
base(380:419, 140:159, 1:3) = image3(1:40, 1:20, 1:3);
base(380:419, 210:229, 1) = image4(1:40, 1:20, 1:3);
base(380:419, 280:299, 1) = image5(1:40, 1:20, 1:3);
base(380:419, 350:369, 1) = image6(1:40, 1:20, 1:3);
base(380:419, 420:439, 1) = image7(1:40, 1:20, 1:3);

    %Second Row 8-14
base(440:479, 1:20, 1) = image8(1:40, 1:20, 1:3);
base(440:479, 70:89, 1) = image9(1:40, 1:20, 1:3);
base(440:479, 140:159, 1) = image1(1:40, 1:20, 1:3); base(440:479, 160:179, 1) = image0(1:40, 1:20, 1:3);
base(440:479, 210:229, 1) = image1(1:40, 1:20, 1:3); base(440:479, 230:249, 1) = image1(1:40, 1:20, 1:3);
base(440:479, 280:299, 1) = image1(1:40, 1:20, 1:3); base(440:479, 300:319, 1) = image2(1:40, 1:20, 1:3);
base(440:479, 350:369, 1) = image1(1:40, 1:20, 1:3); base(440:479, 370:389, 1) = image3(1:40, 1:20, 1:3);
base(440:479, 420:439, 1) = image1(1:40, 1:20, 1:3); base(440:479, 440:459, 1) = image4(1:40, 1:20, 1:3);

    %Third Row 15-21
base(511:550, 1:20, 1) = image1(1:40, 1:20, 1:3); base(511:550, 20:39, 1) = image5(1:40, 1:20, 1:3);
base(511:550, 70:89, 1) = image1(1:40, 1:20, 1:3); base(511:550, 90:109, 1) = image6(1:40, 1:20, 1:3);
base(511:550, 140:159, 1) = image1(1:40, 1:20, 1:3); base(511:550, 160:179, 1) = image7(1:40, 1:20, 1:3);
base(511:550, 210:229, 1) = image1(1:40, 1:20, 1:3); base(511:550, 230:249, 1) = image8(1:40, 1:20, 1:3);
base(511:550, 280:299, 1) = image1(1:40, 1:20, 1:3); base(511:550, 300:319, 1) = image9(1:40, 1:20, 1:3);
base(511:550, 350:369, 1) = image2(1:40, 1:20, 1:3); base(511:550, 370:389, 1) = image0(1:40, 1:20, 1:3);
base(511:550, 420:439, 1) = image2(1:40, 1:20, 1:3); base(511:550, 440:459, 1) = image1(1:40, 1:20, 1:3);

    %Fourth Row 22-28
base(581:620, 1:20, 1) = image2(1:40, 1:20, 1:3); base(581:620, 20:39, 1) = image2(1:40, 1:20, 1:3);
base(581:620, 70:89, 1) = image2(1:40, 1:20, 1:3); base(581:620, 90:109, 1) = image3(1:40, 1:20, 1:3);
base(581:620, 140:159, 1) = image2(1:40, 1:20, 1:3); base(581:620, 160:179, 1) = image4(1:40, 1:20, 1:3);
base(581:620, 210:229, 1) = image2(1:40, 1:20, 1:3); base(581:620, 230:249, 1) = image5(1:40, 1:20, 1:3);
base(581:620, 280:299, 1) = image2(1:40, 1:20, 1:3); base(581:620, 300:319, 1) = image6(1:40, 1:20, 1:3);
base(581:620, 350:369, 1) = image2(1:40, 1:20, 1:3); base(581:620, 370:389, 1) = image7(1:40, 1:20, 1:3);
base(581:620, 420:439, 1) = image2(1:40, 1:20, 1:3); base(581:620, 440:459, 1) = image8(1:40, 1:20, 1:3);

    %Fifth Row 29-31 
base(651:690, 1:20, 1) = image2(1:40, 1:20, 1:3); base(651:690, 20:39, 1) = image9(1:40, 1:20, 1:3);
base(651:690, 70:89, 1) = image3(1:40, 1:20, 1:3); base(651:690, 90:109, 1) = image0(1:40, 1:20, 1:3);
base(651:690, 140:159, 1) = image3(1:40, 1:20, 1:3); base(651:690, 160:179, 1) = image1(1:40, 1:20, 1:3);

%4. Date Insertion
base(315:339, 405:479, 1:3) = month(1:25, 1:75, 1:3);

%5. Background
background = zeros(760, 520, 3);
background = uint8(background);
background(20:739, 20:499,1:3) = base(1:720, 1:480,1:3);
%figure, imshow(base)
figure, imshow(background);